#include <Simulator/io/SimulatorPaths.h>
#include <Simulator/io/YamlConfigParsers.h>

#include "YamlParseUtil.hpp"

#include <vector>

namespace simulator::io {

namespace UC = user_common_207190406_209543255;

namespace {

[[nodiscard]] std::vector<std::filesystem::path>
readPathList(const YAML::Node& node, const char* key) {
    std::vector<std::filesystem::path> paths;
    const YAML::Node list = node[key];
    if (!list || !list.IsSequence()) {
        return paths;
    }
    for (const YAML::Node& entry : list) {
        if (entry.IsScalar()) {
            paths.emplace_back(entry.as<std::string>());
        }
    }
    return paths;
}

[[nodiscard]] bool parseOneSimulationGroup(
    const YAML::Node& entry, const std::filesystem::path& base_dir,
    UC::IRunErrorLog& log, types::SimulationCompositionData& composition) {
    if (!entry["simulation_config"] || !entry["simulation_config"].IsScalar()) {
        detail::logRecoverable(log, "COMPOSITION_INVALID",
                               "[simulation_compositions] entry missing or non-scalar "
                               "simulation_config — skipped");
        return false;
    }

    const auto sim_path =
        resolveConfigPath(base_dir, entry["simulation_config"].as<std::string>());
    const auto sim_result = parseSimulationConfig(sim_path, log);
    if (!sim_result.ok) {
        detail::logRecoverable(log, "COMPOSITION_INVALID",
                               "[simulation_compositions] failed to parse simulation_config \"" +
                                   sim_path.string() + "\" — group skipped");
        return false;
    }
    const types::SimulationConfigData sim_cfg = sim_result.value;

    const YAML::Node mission_list = entry["mission_configs"];
    if (!mission_list || !mission_list.IsSequence() || mission_list.size() == 0) {
        detail::logRecoverable(log, "COMPOSITION_INVALID",
                               "[simulation_compositions] entry missing mission_configs — skipped");
        return false;
    }

    std::vector<common::types::MissionConfigData> missions;
    for (const YAML::Node& mission_entry : mission_list) {
        if (!mission_entry.IsScalar()) {
            continue;
        }
        const auto m_path = resolveConfigPath(base_dir, mission_entry.as<std::string>());
        const auto m_result = parseMissionConfig(m_path, log);
        if (!m_result.ok) {
            detail::logRecoverable(log, "COMPOSITION_INVALID",
                                   "[simulation_compositions] failed to parse mission_config \"" +
                                       m_path.string() + "\" — entry skipped");
            continue;
        }
        missions.push_back(m_result.value);
    }

    if (missions.empty()) {
        return false;
    }
    composition.simulation_mission_groups.emplace_back(sim_cfg, std::move(missions));
    return true;
}

} // namespace

UC::ConfigParseResult<simulator::types::SimulationCompositionData>
parseCompositionFile(const std::filesystem::path& path, UC::IRunErrorLog& log) {
    UC::ConfigParseResult<simulator::types::SimulationCompositionData> result{};

    const auto root = detail::loadYamlFile(path, log, "[simulation_compositions]");
    if (!root.has_value()) {
        result.errors.push_back({"COMPOSITION_FILE_UNREADABLE",
                                  "Could not read composition file: " + path.string()});
        return result;
    }

    const YAML::Node compositions = detail::configRoot(*root, "simulation_compositions");
    const std::filesystem::path base_dir =
        path.has_parent_path() ? path.parent_path() : std::filesystem::path{"."};

    const YAML::Node simulations_yaml = compositions["simulations"];
    if (!simulations_yaml || !simulations_yaml.IsSequence() || simulations_yaml.size() == 0) {
        result.errors.push_back({"COMPOSITION_INVALID",
                                  "simulation_compositions.simulations must be a non-empty sequence"});
        return result;
    }

    types::SimulationCompositionData composition{};
    composition.composition_file = path;

    for (const YAML::Node& entry : simulations_yaml) {
        (void)parseOneSimulationGroup(entry, base_dir, log, composition);
    }

    if (composition.simulation_mission_groups.empty()) {
        result.errors.push_back({"COMPOSITION_INVALID",
                                  "No valid simulation/mission groups found in composition"});
        return result;
    }

    const auto drone_paths = readPathList(compositions, "drone_configs");
    const auto lidar_paths = readPathList(compositions, "lidar_configs");

    if (drone_paths.empty() || lidar_paths.empty()) {
        result.errors.push_back({"COMPOSITION_INVALID",
                                  "simulation_compositions requires non-empty drone_configs and lidar_configs"});
        return result;
    }

    for (const auto& p : drone_paths) {
        const auto drone_result = parseDroneConfig(resolveConfigPath(base_dir, p), log);
        if (!drone_result.ok) {
            result.errors.push_back({"COMPOSITION_INVALID",
                                      "Failed to parse drone_config \"" +
                                          resolveConfigPath(base_dir, p).string() + "\""});
            return result;
        }
        composition.drone_configs.push_back(drone_result.value);
    }
    for (const auto& p : lidar_paths) {
        const auto lidar_result = parseLidarConfig(resolveConfigPath(base_dir, p), log);
        if (!lidar_result.ok) {
            result.errors.push_back({"COMPOSITION_INVALID",
                                      "Failed to parse lidar_config \"" +
                                          resolveConfigPath(base_dir, p).string() + "\""});
            return result;
        }
        composition.lidar_configs.push_back(lidar_result.value);
    }

    result.ok    = true;
    result.value = std::move(composition);
    return result;
}

} // namespace simulator::io
